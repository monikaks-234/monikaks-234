import cv2
import numpy as np
from PIL import Image
import os

def train_model():
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    detector = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

    faces = []
    ids = []

    for user_folder in os.listdir('dataset'):
        path = os.path.join('dataset', user_folder)
        if not os.path.isdir(path):
            continue

        for img_name in os.listdir(path):
            img_path = os.path.join(path, img_name)
            pil_image = Image.open(img_path).convert('L')
            image_np = np.array(pil_image, 'uint8')
            id = int(user_folder)
            faces.append(image_np)
            ids.append(id)

    recognizer.train(faces, np.array(ids))
    os.makedirs("trainer", exist_ok=True)
    recognizer.save("trainer/trainer.yml")
    print("Model trained and saved successfully.")

if __name__ == "__main__":
    train_model()
